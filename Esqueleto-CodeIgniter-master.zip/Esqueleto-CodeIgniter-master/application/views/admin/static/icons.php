<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">202 Awesome Stroke Icons</h4>
                                <p class="category">Handcrafted by our friends from <a target="_blank" href="http://themes-pixeden.com/font-demos/7-stroke/index.html">Pixeden</a></p>
                            </div>
                            <div class="content all-icons">
                                <div class="row">
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-album"></i>
                                      <input type="text" value="pe-7s-album">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-arc"></i>
                                      <input type="text" value="pe-7s-arc">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-back-2"></i>
                                      <input type="text" value="pe-7s-back-2">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-bandaid"></i>
                                      <input type="text" value="pe-7s-bandaid">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-car"></i>
                                      <input type="text" value="pe-7s-car">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-diamond"></i>
                                      <input type="text" value="pe-7s-diamond">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-door-lock"></i>
                                      <input type="text" value="pe-7s-door-lock">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-eyedropper"></i>
                                      <input type="text" value="pe-7s-eyedropper">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-female"></i>
                                      <input type="text" value="pe-7s-female">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-gym"></i>
                                      <input type="text" value="pe-7s-gym">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-hammer"></i>
                                      <input type="text" value="pe-7s-hammer">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-headphones"></i>
                                      <input type="text" value="pe-7s-headphones">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-helm"></i>
                                      <input type="text" value="pe-7s-helm">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-hourglass"></i>
                                      <input type="text" value="pe-7s-hourglass">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-leaf"></i>
                                      <input type="text" value="pe-7s-leaf">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-magic-wand"></i>
                                      <input type="text" value="pe-7s-magic-wand">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-male"></i>
                                      <input type="text" value="pe-7s-male">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-map-2"></i>
                                      <input type="text" value="pe-7s-map-2">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-next-2"></i>
                                      <input type="text" value="pe-7s-next-2">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-paint-bucket"></i>
                                      <input type="text" value="pe-7s-paint-bucket">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-pendrive"></i>
                                      <input type="text" value="pe-7s-pendrive">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-photo"></i>
                                      <input type="text" value="pe-7s-photo">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-piggy"></i>
                                      <input type="text" value="pe-7s-piggy">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-plugin"></i>
                                      <input type="text" value="pe-7s-plugin">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-refresh-2"></i>
                                      <input type="text" value="pe-7s-refresh-2">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-rocket"></i>
                                      <input type="text" value="pe-7s-rocket">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-settings"></i>
                                      <input type="text" value="pe-7s-settings">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-shield"></i>
                                      <input type="text" value="pe-7s-shield">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-smile"></i>
                                      <input type="text" value="pe-7s-smile">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-usb"></i>
                                      <input type="text" value="pe-7s-usb">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-vector"></i>
                                      <input type="text" value="pe-7s-vector">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-wine"></i>
                                      <input type="text" value="pe-7s-wine">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-cloud-upload"></i>
                                      <input type="text" value="pe-7s-cloud-upload">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-cash"></i>
                                      <input type="text" value="pe-7s-cash">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-close"></i>
                                      <input type="text" value="pe-7s-close">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-bluetooth"></i>
                                      <input type="text" value="pe-7s-bluetooth">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-cloud-download"></i>
                                      <input type="text" value="pe-7s-cloud-download">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-way"></i>
                                      <input type="text" value="pe-7s-way">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-close-circle"></i>
                                      <input type="text" value="pe-7s-close-circle">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-id"></i>
                                      <input type="text" value="pe-7s-id">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-angle-up"></i>
                                      <input type="text" value="pe-7s-angle-up">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-wristwatch"></i>
                                      <input type="text" value="pe-7s-wristwatch">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-angle-up-circle"></i>
                                      <input type="text" value="pe-7s-angle-up-circle">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-world"></i>
                                      <input type="text" value="pe-7s-world">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-angle-right"></i>
                                      <input type="text" value="pe-7s-angle-right">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-volume"></i>
                                      <input type="text" value="pe-7s-volume">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-angle-right-circle"></i>
                                      <input type="text" value="pe-7s-angle-right-circle">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-users"></i>
                                      <input type="text" value="pe-7s-users">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-angle-left"></i>
                                      <input type="text" value="pe-7s-angle-left">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-user-female"></i>
                                      <input type="text" value="pe-7s-user-female">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-angle-left-circle"></i>
                                      <input type="text" value="pe-7s-angle-left-circle">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-up-arrow"></i>
                                      <input type="text" value="pe-7s-up-arrow">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-angle-down"></i>
                                      <input type="text" value="pe-7s-angle-down">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-switch"></i>
                                      <input type="text" value="pe-7s-switch">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-angle-down-circle"></i>
                                      <input type="text" value="pe-7s-angle-down-circle">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-scissors"></i>
                                      <input type="text" value="pe-7s-scissors">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-wallet"></i>
                                      <input type="text" value="pe-7s-wallet">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-safe"></i>
                                      <input type="text" value="pe-7s-safe">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-volume2"></i>
                                      <input type="text" value="pe-7s-volume2">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-volume1"></i>
                                      <input type="text" value="pe-7s-volume1">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-voicemail"></i>
                                      <input type="text" value="pe-7s-voicemail">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-video"></i>
                                      <input type="text" value="pe-7s-video">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-user"></i>
                                      <input type="text" value="pe-7s-user">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-upload"></i>
                                      <input type="text" value="pe-7s-upload">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-unlock"></i>
                                      <input type="text" value="pe-7s-unlock">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-umbrella"></i>
                                      <input type="text" value="pe-7s-umbrella">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-trash"></i>
                                      <input type="text" value="pe-7s-trash">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-tools"></i>
                                      <input type="text" value="pe-7s-tools">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-timer"></i>
                                      <input type="text" value="pe-7s-timer">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-ticket"></i>
                                      <input type="text" value="pe-7s-ticket">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-target"></i>
                                      <input type="text" value="pe-7s-target">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-sun"></i>
                                      <input type="text" value="pe-7s-sun">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-study"></i>
                                      <input type="text" value="pe-7s-study">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-stopwatch"></i>
                                      <input type="text" value="pe-7s-stopwatch">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-star"></i>
                                      <input type="text" value="pe-7s-star">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-speaker"></i>
                                      <input type="text" value="pe-7s-speaker">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-signal"></i>
                                      <input type="text" value="pe-7s-signal">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-shuffle"></i>
                                      <input type="text" value="pe-7s-shuffle">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-shopbag"></i>
                                      <input type="text" value="pe-7s-shopbag">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-share"></i>
                                      <input type="text" value="pe-7s-share">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-server"></i>
                                      <input type="text" value="pe-7s-server">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-search"></i>
                                      <input type="text" value="pe-7s-search">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-film"></i>
                                      <input type="text" value="pe-7s-film">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-science"></i>
                                      <input type="text" value="pe-7s-science">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-disk"></i>
                                      <input type="text" value="pe-7s-disk">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-ribbon"></i>
                                      <input type="text" value="pe-7s-ribbon">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-repeat"></i>
                                      <input type="text" value="pe-7s-repeat">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-refresh"></i>
                                      <input type="text" value="pe-7s-refresh">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-add-user"></i>
                                      <input type="text" value="pe-7s-add-user">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-refresh-cloud"></i>
                                      <input type="text" value="pe-7s-refresh-cloud">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-paperclip"></i>
                                      <input type="text" value="pe-7s-paperclip">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-radio"></i>
                                      <input type="text" value="pe-7s-radio">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-note2"></i>
                                      <input type="text" value="pe-7s-note2">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-print"></i>
                                      <input type="text" value="pe-7s-print">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-network"></i>
                                      <input type="text" value="pe-7s-network">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-prev"></i>
                                      <input type="text" value="pe-7s-prev">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-mute"></i>
                                      <input type="text" value="pe-7s-mute">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-power"></i>
                                      <input type="text" value="pe-7s-power">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-medal"></i>
                                      <input type="text" value="pe-7s-medal">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-portfolio"></i>
                                      <input type="text" value="pe-7s-portfolio">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-like2"></i>
                                      <input type="text" value="pe-7s-like2">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-plus"></i>
                                      <input type="text" value="pe-7s-plus">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-left-arrow"></i>
                                      <input type="text" value="pe-7s-left-arrow">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-play"></i>
                                      <input type="text" value="pe-7s-play">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-key"></i>
                                      <input type="text" value="pe-7s-key">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-plane"></i>
                                      <input type="text" value="pe-7s-plane">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-joy"></i>
                                      <input type="text" value="pe-7s-joy">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-photo-gallery"></i>
                                      <input type="text" value="pe-7s-photo-gallery">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-pin"></i>
                                      <input type="text" value="pe-7s-pin">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-phone"></i>
                                      <input type="text" value="pe-7s-phone">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-plug"></i>
                                      <input type="text" value="pe-7s-plug">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-pen"></i>
                                      <input type="text" value="pe-7s-pen">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-right-arrow"></i>
                                      <input type="text" value="pe-7s-right-arrow">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-paper-plane"></i>
                                      <input type="text" value="pe-7s-paper-plane">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-delete-user"></i>
                                      <input type="text" value="pe-7s-delete-user">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-paint"></i>
                                      <input type="text" value="pe-7s-paint">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-bottom-arrow"></i>
                                      <input type="text" value="pe-7s-bottom-arrow">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-notebook"></i>
                                      <input type="text" value="pe-7s-notebook">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-note"></i>
                                      <input type="text" value="pe-7s-note">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-next"></i>
                                      <input type="text" value="pe-7s-next">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-news-paper"></i>
                                      <input type="text" value="pe-7s-news-paper">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-musiclist"></i>
                                      <input type="text" value="pe-7s-musiclist">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-music"></i>
                                      <input type="text" value="pe-7s-music">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-mouse"></i>
                                      <input type="text" value="pe-7s-mouse">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-more"></i>
                                      <input type="text" value="pe-7s-more">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-moon"></i>
                                      <input type="text" value="pe-7s-moon">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-monitor"></i>
                                      <input type="text" value="pe-7s-monitor">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-micro"></i>
                                      <input type="text" value="pe-7s-micro">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-menu"></i>
                                      <input type="text" value="pe-7s-menu">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-map"></i>
                                      <input type="text" value="pe-7s-map">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-map-marker"></i>
                                      <input type="text" value="pe-7s-map-marker">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-mail"></i>
                                      <input type="text" value="pe-7s-mail">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-mail-open"></i>
                                      <input type="text" value="pe-7s-mail-open">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-mail-open-file"></i>
                                      <input type="text" value="pe-7s-mail-open-file">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-magnet"></i>
                                      <input type="text" value="pe-7s-magnet">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-loop"></i>
                                      <input type="text" value="pe-7s-loop">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-look"></i>
                                      <input type="text" value="pe-7s-look">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-lock"></i>
                                      <input type="text" value="pe-7s-lock">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-lintern"></i>
                                      <input type="text" value="pe-7s-lintern">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-link"></i>
                                      <input type="text" value="pe-7s-link">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-like"></i>
                                      <input type="text" value="pe-7s-like">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-light"></i>
                                      <input type="text" value="pe-7s-light">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-less"></i>
                                      <input type="text" value="pe-7s-less">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-keypad"></i>
                                      <input type="text" value="pe-7s-keypad">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-junk"></i>
                                      <input type="text" value="pe-7s-junk">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-info"></i>
                                      <input type="text" value="pe-7s-info">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-home"></i>
                                      <input type="text" value="pe-7s-home">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-help2"></i>
                                      <input type="text" value="pe-7s-help2">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-help1"></i>
                                      <input type="text" value="pe-7s-help1">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-graph3"></i>
                                      <input type="text" value="pe-7s-graph3">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-graph2"></i>
                                      <input type="text" value="pe-7s-graph2">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-graph1"></i>
                                      <input type="text" value="pe-7s-graph1">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-graph"></i>
                                      <input type="text" value="pe-7s-graph">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-global"></i>
                                      <input type="text" value="pe-7s-global">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-gleam"></i>
                                      <input type="text" value="pe-7s-gleam">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-glasses"></i>
                                      <input type="text" value="pe-7s-glasses">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-gift"></i>
                                      <input type="text" value="pe-7s-gift">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-folder"></i>
                                      <input type="text" value="pe-7s-folder">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-flag"></i>
                                      <input type="text" value="pe-7s-flag">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-filter"></i>
                                      <input type="text" value="pe-7s-filter">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-file"></i>
                                      <input type="text" value="pe-7s-file">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-expand1"></i>
                                      <input type="text" value="pe-7s-expand1">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-exapnd2"></i>
                                      <input type="text" value="pe-7s-exapnd2">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-edit"></i>
                                      <input type="text" value="pe-7s-edit">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-drop"></i>
                                      <input type="text" value="pe-7s-drop">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-drawer"></i>
                                      <input type="text" value="pe-7s-drawer">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-download"></i>
                                      <input type="text" value="pe-7s-download">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-display2"></i>
                                      <input type="text" value="pe-7s-display2">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-display1"></i>
                                      <input type="text" value="pe-7s-display1">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-diskette"></i>
                                      <input type="text" value="pe-7s-diskette">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-date"></i>
                                      <input type="text" value="pe-7s-date">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-cup"></i>
                                      <input type="text" value="pe-7s-cup">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-culture"></i>
                                      <input type="text" value="pe-7s-culture">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-crop"></i>
                                      <input type="text" value="pe-7s-crop">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-credit"></i>
                                      <input type="text" value="pe-7s-credit">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-copy-file"></i>
                                      <input type="text" value="pe-7s-copy-file">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-config"></i>
                                      <input type="text" value="pe-7s-config">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-compass"></i>
                                      <input type="text" value="pe-7s-compass">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-comment"></i>
                                      <input type="text" value="pe-7s-comment">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-coffee"></i>
                                      <input type="text" value="pe-7s-coffee">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-cloud"></i>
                                      <input type="text" value="pe-7s-cloud">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-clock"></i>
                                      <input type="text" value="pe-7s-clock">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-check"></i>
                                      <input type="text" value="pe-7s-check">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-chat"></i>
                                      <input type="text" value="pe-7s-chat">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-cart"></i>
                                      <input type="text" value="pe-7s-cart">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-camera"></i>
                                      <input type="text" value="pe-7s-camera">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-call"></i>
                                      <input type="text" value="pe-7s-call">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-calculator"></i>
                                      <input type="text" value="pe-7s-calculator">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-browser"></i>
                                      <input type="text" value="pe-7s-browser">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-box2"></i>
                                      <input type="text" value="pe-7s-box2">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-box1"></i>
                                      <input type="text" value="pe-7s-box1">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-bookmarks"></i>
                                      <input type="text" value="pe-7s-bookmarks">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-bicycle"></i>
                                      <input type="text" value="pe-7s-bicycle">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-bell"></i>
                                      <input type="text" value="pe-7s-bell">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-battery"></i>
                                      <input type="text" value="pe-7s-battery">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-ball"></i>
                                      <input type="text" value="pe-7s-ball">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-back"></i>
                                      <input type="text" value="pe-7s-back">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-attention"></i>
                                      <input type="text" value="pe-7s-attention">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-anchor"></i>
                                      <input type="text" value="pe-7s-anchor">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-albums"></i>
                                      <input type="text" value="pe-7s-albums">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-alarm"></i>
                                      <input type="text" value="pe-7s-alarm">
                                    </div>

                                  </div>
                                  <div class="font-icon-list col-lg-2 col-md-3 col-sm-4 col-xs-6 col-xs-6">
                                    <div class="font-icon-detail"><i class="pe-7s-airplay"></i>
                                      <input type="text" value="pe-7s-airplay">
                                    </div>

                                  </div>
                                </div>


                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>