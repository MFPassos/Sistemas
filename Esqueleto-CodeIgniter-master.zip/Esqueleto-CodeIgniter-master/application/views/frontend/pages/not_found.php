<h2>Erro 404</h2>
<hr>
<p>A página que você procura não pôde ser encontrada! <a href="<?=base_url()?>">Voltar para a Home</a></p>